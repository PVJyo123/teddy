const fs = require("fs");
const http = require("http");
const { execFile } = require("child_process");
const path = require("path");

const server = http.createServer();
const fileName = "./resources/recording.wav";
const responseFileName = "./resources/response.wav";

server.on("request", (request, response) => {
    if (request.method === "POST" && request.url === "/uploadAudio") {
        console.log("Received audio upload request");
        
        let recordingFile = fs.createWriteStream(fileName, { encoding: "binary" });

        request.on("data", function(data) {
            recordingFile.write(data);
        });

        request.on("end", function() {
            recordingFile.end();
            console.log("Finished receiving audio file");

            // Call the Python script and get its output
            console.log("Calling Python script to process audio");
            execFile("python3", ["process_audio.py", fileName], (error, stdout, stderr) => {
                console.log(`Python script stdout: ${stdout}`);
                if (stderr) {
                    console.error(`Python script stderr: ${stderr}`);
                }
                
                if (error) {
                    console.error(`exec error: ${error.message}`);
                    response.writeHead(500, { "Content-Type": "text/plain" });
                    response.end("Internal Server Error");
                    return;
                }
            
                console.log("Checking for response file...");
                if (fs.existsSync(responseFileName)) {
                    console.log(`Response file found at ${responseFileName}`);
                    // Continue with sending the file...
                } else {
                    console.error(`Response file not found at ${responseFileName}`);
                    response.writeHead(500, { "Content-Type": "text/plain" });
                    response.end("Response file not generated");
                    return;
                }
            
                // Continue with reading the response file...

                // Read the response audio file
                console.log("Reading response audio file");
                fs.readFile(responseFileName, (err, data) => {
                    if (err) {
                        console.error(`Error reading response file: ${err}`);
                        response.writeHead(500, { "Content-Type": "text/plain" });
                        response.end("Internal Server Error");
                        return;
                    }
                
                    console.log(`Response audio file size: ${data.length} bytes`);
                    
                    // Send the audio file back to the client
                    console.log("Sending response audio back to client");
                    response.writeHead(200, { 
                        "Content-Type": "audio/wav",
                        "Content-Length": data.length
                    });
                    response.end(data);
                
                    console.log("Response audio sent successfully");

                    // Clean up the files
                    console.log("Cleaning up temporary files");
                    fs.unlink(fileName, (err) => {
                    if (err) console.error(`Error deleting recording file: ${err}`);
                    });
//              fs.unlink(responseFileName, (err) => {
//                      if (err) console.error(`Error deleting response file: ${err}`);
//                 });
                });
            });
        });

        request.on("error", (err) => {
            console.error(`Request error: ${err}`);
            response.writeHead(500, { "Content-Type": "text/plain" });
            response.end("Internal Server Error");
        });
    } else {
        console.log(`Received unsupported request: ${request.method} ${request.url}`);
        response.writeHead(405, { "Content-Type": "text/plain" });
        response.end("Method Not Allowed");
    }
});

const port = 8888;
server.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
    console.log(`Waiting for audio uploads...`);
});

// Handle server errors
server.on('error', (error) => {
    console.error(`Server error: ${error}`);
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
    console.error(`Uncaught exception: ${error}`);
});

// Ensure the resources directory exists
const resourcesDir = path.join(__dirname, 'resources');
if (!fs.existsSync(resourcesDir)){
    fs.mkdirSync(resourcesDir);
    console.log('Created resources directory');
}