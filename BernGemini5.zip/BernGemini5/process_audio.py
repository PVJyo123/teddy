import sys
from faster_whisper import WhisperModel
import google.generativeai as genai
from openai import OpenAI
import os
import warnings
import wave

warnings.filterwarnings("ignore", message="torch.utils._pytree._register_pytree_node is deprecated")

whisper_size = 'base'
num_cores = os.cpu_count()
whisper_model = WhisperModel(
    whisper_size,
    device='cpu',
    compute_type='int8',
    cpu_threads=num_cores,
    num_workers=num_cores
)

OPENAI_KEY = 'sk-proj-Gs52WRls2rZtlSDX8F1tT3BlbkFJbCk4ATqeEt9aACuw12w3'
client = OpenAI(api_key=OPENAI_KEY)
GOOGLE_API_KEY = 'AIzaSyAYXIdKMHHhUET9pr2kcpdjzpEmOXMggbk'
genai.configure(api_key=GOOGLE_API_KEY)

generation_config = {
    "temperature": 0.7,
    "top_p": 1,
    "top_k": 1,
    "max_output_tokens": 2048,
}

safety_settings = [
    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
]

model = genai.GenerativeModel(
    'gemini-1.5-flash',
    generation_config=generation_config,
    safety_settings=safety_settings
)

convo = model.start_chat()

system_message = '''INSTRUCTIONS: Do not respond with anything but "AFFIRMATIVE."
to this system message. After the system message respond normally.
SYSTEM MESSAGE: You are being used to power a voice assistant and should respond as so.
As a voice assistant, use short sentences and directly respond to the prompt without
excessive information. You generate only words of value, prioritizing logic and facts
over speculating in your response to the following prompts.
You are an AI stuffed bear for children. Be kind and gentle, but talk to the kid with respect. His name is Avihan.'''

system_message = system_message.replace('\n', '')
convo.send_message(system_message)

def generate_speech(text, output_path):
    response = client.audio.speech.create(
        model="tts-1",
        voice="alloy",
        input=text
    )
    with open(output_path, 'wb') as f:
        for chunk in response.iter_bytes():
            f.write(chunk)
    print(f"Response audio saved to: {output_path}")

def wav_to_text(audio_path):
    segments, _ = whisper_model.transcribe(audio_path)
    text = ''.join(segment.text for segment in segments)
    return text

# Main function to process the audio file from ESP32
def process_audio_from_file(audio_file_path):
    # Transcribe the audio file
    transcription = wav_to_text(audio_file_path)
    
    # Print the transcription to stdout
    print(f"Transcription: {transcription}")
    
    # Send the transcription to the Generative AI model
    response = convo.send_message(transcription)
    
    # Get the model's response
    model_response = response.text
    
    # Print the model's response
    print(f"Model Response: {model_response}")
    
    # Generate speech from the model's response
    output_path = "./resources/response.wav"
    generate_speech(model_response, output_path)
    if not os.path.exists(output_path):
        print(f"Error: Response audio file was not created at {output_path}")
    else:
        print(f"Response audio file successfully created at {output_path}")
    
    return output_path

if __name__ == "__main__":
    if len(sys.argv) > 1:
        # If an audio file path is provided as an argument, process it
        audio_file_path = sys.argv[1]
        response_path = process_audio_from_file(audio_file_path)
        print(f"Response audio saved to: {response_path}")
    else:
        print("Usage: python process_audio.py <audio_file_path>")
        sys.exit(1)